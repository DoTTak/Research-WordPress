<?php

?>
<div class="background__white radius-25 p40">
	<div class="upgrage__card__tab__style">
		<h3><?php esc_html_e( "Why upgrade to Premium Version?", "embedpress" ); ?></h3>
        <p><?php esc_html_e( "The premium version helps us to continue development of the product incorporating even more features and enhancements. You will also get world class support from our dedicated team, 24/7.", "embedpress" ); ?></p>
		<a href="<?php echo esc_url('https://wpdeveloper.com/in/upgrade-embedpress'); ?>" target="_blank" class="button button__themeColor radius-10"><?php esc_html_e( "Get Premium Version", "embedpress" ); ?></a>
	</div>
</div>
