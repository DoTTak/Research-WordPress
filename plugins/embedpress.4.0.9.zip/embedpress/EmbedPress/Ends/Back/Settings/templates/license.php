<?php
/*
 * License Settings page */

do_action( 'embedpress_license', $nonce_field);
?>
